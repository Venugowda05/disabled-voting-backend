def send_otp(phone: str):
    print(f"Sending OTP to {phone}")
    return "1234"