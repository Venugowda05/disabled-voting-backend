# Disabled Voting Backend
FastAPI backend for a simple disabled-friendly voting system.